#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);
    
    int a;
    cout << "Введите число: ";
    cin >> a;

    if (a <= 1) 
    {
        cout << a << " не является простым числом" << endl;
        return 0;
    }

    bool Prime = true;  

    for (int i = 2; i < a; i++) 
    {
        if (a % i == 0) {
            Prime = false;
            break;
        }
    }

    if (Prime) 
    {
        cout << a << " является простым числом" << endl;
    } 

    else 
    {
        cout << a << " не является простым числом" << endl;
    }
    
    return 0;
}