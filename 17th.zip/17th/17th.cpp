#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int age;
    cout << "Введите ваш возраст";
    cin >> age;

    bool driver_license = true;
    string ans;
    cout << "У вас есть водительские права?" << endl;
    cin >> ans;
    if (ans == "нет" || ans == "no" || ans == "n" ) {
        driver_license = false;
    }

    bool is_sober = true;
    string answ;
    cout << "Вы трезвый?" << endl;
    cin >> answ;
    if (answ == "нет" || answ == "no" || answ == "n" ); {
        is_sober = false;
    }


    if (age >=18 && driver_license && is_sober) {
        cout << "Вы можете водить машину" << endl;
    }
    else {
        cout << "Вы не можете водить машину" << endl;
        
        if (age <18) {
            cout << "Потомучто не совершенолетний" << endl;
        }
        else if (!driver_license) {
            cout<<"Потомучто нет лицензии"<< endl;
        } 
        else if (!is_sober) {
            cout<<"Потомучто пьяный"<< endl;
        }
   }
   return 0;
}