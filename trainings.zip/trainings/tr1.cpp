#include <iostream>
using namespace std;

int main() {
    char operation;
    double num1, num2, result;

    while (true) {
        cout << "Write an operation: ";
        cin >> operation;

        if (operation == '+' || operation == '-' || operation == '*' || operation == '/') {
            break;
        } else {
            cout << "Wrong operation, pls enter +, -, *, or /." << endl;
            cin.clear();
            cin.ignore(10000, '\n');
        }
    }

    cout << "Write 1st number: ";
    cin >> num1;
    cout << "Write 2nd number: ";
    cin >> num2;
    
    switch (operation)
    {
    case '+':
        result = num1 + num2;
        cout << result << endl;
        break;
    case '-':
        result = num1 - num2;
        cout << result << endl;
        break;
    case '*':
        result = num1 * num2;
        cout << result << endl;
        break;
    case '/':
        if (num2 != 0) {
            result = num1 / num2;
            cout << result << endl;
        }
        else {
            cout << "Ur 2nd number is 0, u can't do this" << endl;
        }
        break;
    }
    return 0;
}