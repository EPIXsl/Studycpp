#include <iostream>
#include <iomanip>
using namespace std;
    int main() {
        int USDcurrency = 90;
        double cur1, result;

        cout << "Write a sum in rub";
        cin >> cur1;

        result = cur1 / USDcurrency;
        cout << fixed << setprecision(2);
        cout << result << endl;

        return 0;
}