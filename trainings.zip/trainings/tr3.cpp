#include <iostream>
#include <iomanip>
#include <windows.h>
using namespace std;

    int main () {

        SetConsoleOutputCP(CP_UTF8);

        double height, weight, result;

        cout << "Write ur weight:";
        cin >> weight;
        cout << "Write ur height:";
        cin >> height;

        height = height / 100;
        result = weight / (height * height);
        cout << fixed << setprecision(2);
        cout << "UR IMT " << result << endl;
    
        if (result < 18.5) {
            cout << "Хуйня вес";
        }
        else if (result < 25)
        {
            cout << "Норм";
        }
        else if (result < 30)
        {
            cout << "Ты жирный";

        }
        
        else if (result < 500)
        {
            cout << "Ебать ты тумбочка ебаная";
        }
        
        else
        {
            cout << "Ты пизда какой жирный";

        }
        
        cout << ")" << endl;

        return 0;

    
    }