#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);
    double radius;
    cout << "Введите радиус";
    cin >> radius;

    double S = 3.1415926535 * radius * radius;
    cout << "Площадь круга:" << S << endl;
    
    return 0;}