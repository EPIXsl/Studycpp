#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int score;
    cout << "Введите ваш балл";
    cin >> score;

    if (score >=80) {
        cout << "Ваша оценка 5" << endl;
    }
    else if (score <= 79 && score >= 60) {
        cout << "Ваша оценка 4" << endl;
    }

    else if (score <= 59 && score >= 40) {
        cout << "Ваша оценка 3" << endl;
    }
    else if (score <=39) {
        cout << "Ваша оценка 2" << endl;
    }
    return 0;
}