#include <iostream>
#include <windows.h>
using namespace std;

int printTable(int number) {
    for (int i = 1; i <= 10; i++) {
        cout << i << " * " << number << " = " << (i * number) << endl;
    }
    return number;
}

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int a;
    cout << "Введите число ";
    cin >> a;
    
    int result = printTable(a);
    cout << "Обработанное число" << result << endl;
    
    return 0;
}
