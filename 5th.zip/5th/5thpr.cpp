#include <iostream>
#include <iomanip>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int num;
    cout << "Введите число: ";
    cin >> num;
    
    if (cin.fail()) {
        cout << "Введите целое число" << endl;
        return 1;
    }

    string result = (num % 2 == 0) ? "Четное" : "Нечетное";
    cout << "Число" << num << result << endl;
    
    return 0;
}