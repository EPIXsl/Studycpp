#include <iostream>
#include <iomanip>
#include <windows.h>
using namespace std;

int main () {

    SetConsoleOutputCP(CP_UTF8);

    int num, result1, result2, result3;
    cout << "Wrire a number";
    cin >> num;

    if (num % 2 == 0) {
        cout << "Чётное" << endl;
    } 
    else {
        cout << "Нечётное" << endl;
    }

    if (num < 0) {
        cout << "Отрицательное" << endl;
    }
    else {
        cout << "Положительное" << endl;
    }

    if (num >= 10 && num <= 99) {
        cout << "Двузначное" << endl;
    }

    else if (num <= -10 && num <= 99)
    {
        cout << "Двузначное отрицательное" << endl;
    }
    
    else
    {
        cout << "Недвузначное" << endl;
    }
    
    return 0;
}