#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int num, sum = 0;
    cout << "Введите число";
    cin >> num;

    while (num != 0)
    {
        sum += num % 10;
        num /=10;
    }
    cout << "Сумма чисел" << sum << endl;
}
    