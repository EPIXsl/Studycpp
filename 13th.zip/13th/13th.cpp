#include <iostream>
#include <vector>
#include <cmath>
#include <windows.h>
#include <iomanip>

using namespace std;

double polynomial(double x) {
    return x*x*x - 3*x*x + 2*x;
}

double findRoot(double a, double b, double epsilon = 0.0001) {
    double fa = polynomial(a);
    double fb = polynomial(b);
    
    if (fa * fb > 0) {
        return NAN;
    }
    
    while (b - a > epsilon) {
        double mid = (a + b) / 2;
        double fmid = polynomial(mid);
        
        if (abs(fmid) < epsilon) {
            return mid;
        }
        
        if (fa * fmid < 0) {
            b = mid;
            fb = fmid;
        } else {
            a = mid;
            fa = fmid;
        }
    }
    
    return (a + b) / 2;
}

int main() {

    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
    
    cout << "многочлен: x^3 - 3x^2 + 2x" << endl;
    
    vector<double> roots;
    
    for (double x = -2.0; x <= 3.0; x += 0.01) {
        if (abs(polynomial(x)) < 0.001) {
            bool isNew = true;
            for (double existing : roots) {
                if (abs(existing - x) < 0.1) {
                    isNew = false;
                    break;
                }
            }
            if (isNew) {
                roots.push_back(x);
            }
        }
    }
    
    for (int i = 0; i < roots.size(); i++) {
        double refined = findRoot(roots[i] - 0.1, roots[i] + 0.1);
        if (!isnan(refined)) {
            roots[i] = refined;
        }
    }
    
    cout << "корни: ";
    for (double root : roots) {
        if (abs(root) < 0.001) root = 0.0;
        cout << fixed << setprecision(2) << root << " ";
    }
    cout << endl;
    
    cout << "разложение на множители:";
    if (!roots.empty()) {
        for (double root : roots) {
            if (abs(root) < 0.001) {
                cout << "x";
            } else if (root > 0) {
                cout << "(x - " << fixed << setprecision(2) << root << ")";
            } else {
                cout << "(x + " << fixed << setprecision(2) << -root << ")";
            }
        }
    } else {
        cout << "не удалось разложить";
    }
    cout << endl;
    
    cout << "\nпроверка:" << endl;
    for (double root : roots) {
        double value = polynomial(root);
        cout << "P(" << fixed << setprecision(2) << root << ") = " << value << endl;
    }
    
    return 0;
}