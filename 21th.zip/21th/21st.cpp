#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    string name;
    cout << "Введите ваше имя" << endl;
    cin >> name;

    int age;
    cout << "Введите ваш возраст" << endl;
    cin >> age;

    double average_grade;
    cout << "Введите ваш средний балл" << endl;
    cin >> average_grade;

    string has_scholarship;
    cout << "У вас есть стипендия?" << endl;
    cin >> has_scholarship;

    int course;
    cout << "Введите ваш курс" << endl;
    cin >> course;


    bool can_advance = (average_grade >= 4.0) && (course <= 3) && (age <= 25); //Часть значит true

    if (!can_advance)
    {
        cout << "Информация о студенте: " << endl << "Имя студента: " << name << endl << 
        "Возраст студента: " << age << endl << "Средний балл студента: " << average_grade << 
        endl << "Наличие стипендии у студента: " << has_scholarship << endl << "Год обучения стундента: " << course << endl;

        cout << "Вы не можете перейти на следующий курс по причине:" << endl;
        
        bool has_reasons = false;
    
        if (average_grade < 4.0) {
            cout << "- Низкий средний балл (" << average_grade << ")" << endl;
            has_reasons = true;
        }
        
        if (course >= 4) {
            cout << "- Последний курс" << endl;
            has_reasons = true;
        }
        
        if (age > 25) {
            cout << "- Превышен максимальный возраст (" << age << " лет)" << endl;
            has_reasons = true;
        }
        
        if (!has_reasons) {
            cout << "- Неизвестная причина" << endl;
        } 
    }
    
    else
    {
        cout << "Информация о студенте: " << endl << "Имя студента: " << name << endl << 
        "Возраст студента: " << age << endl << "Средний балл студента: " << average_grade << 
        endl << "Наличие стипендии у студента: " << has_scholarship << endl << "Год обучения стундента: " << course << endl;
        cout << "Вы можете перейти на следующий курс" << endl;
    }
    

    return 0;
}
