#include <iostream>
#include <cstdlib>
#include <ctime>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);
    
    srand(time(0));
    int secret = rand() % 100 + 1;
    int guess, attempts = 0;

    cout << "Угадай число от 1 до 100" << endl;

    do {
        cout << "Твой ход: ";
        cin >> guess;
        attempts++;

        if (guess > secret) {
            cout << "Меньше" << endl;
        }
        else if (guess < secret) {
            cout << "Больше" << endl;
        }

    } while (guess != secret);

    cout << "Угаданно за " << attempts << " попыток" << endl;
    
    return 0;
}