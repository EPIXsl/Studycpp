#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int n;
    cout << "Введите число";
    cin >> n;

    for (int i = 2; i <= n; i++)
    {
        bool ip = true;
        for (int o = 2; o * o <= i; o++)
        {
            if (i % o == 0){
                ip = false;
                break;
            }
        }
        if (ip) cout << i << " ";
        
    }
}