#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int N, sum = 0;
    cout << "Введите число N: ";
    cin >> N;

    cout << "Чётные числа: ";
    for (int i = 1; i <= N; i++) {
        if (i % 2 != 0) continue;
        cout << i << " ";
        sum += i;
    }

    cout << "Сумма чётных чисел:" << sum << endl;
    return 0;
}