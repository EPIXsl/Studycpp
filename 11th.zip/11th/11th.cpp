#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int n, a = 0, b = 1;
    cout << "Введи число";
    cin >> n;

    for (int i = 2; i < n; i++)
    {
        int next = a + b;
        cout << next<< " ";
        a = b;
        b = next;
    }
}