#include <iostream>
#include <windows.h>
using namespace std;

void deposit(double& account, double amount) {
    account = account + amount;
    cout << "Пополнение +" << amount << endl;
}

void withdraw(double& account, double amount) {
    if (account >= amount)
    {
        account = account - amount;
        cout << "Списание -" << amount <<endl;
    }
    else
    {
        cout << "Недостаточно средст на счете" << endl;
    }
}

void checkBalance(const double& account) {
    cout << "Ваш баланс " << account << endl; 
}

void transfer(double* fromAccount, double* toAccount, double amount) {

    if (fromAccount == nullptr)
    {
        cout << "Счета не существует" << endl;
    }
    
    if (toAccount == nullptr)
    {
        cout << "Счета не существует" << endl;
    }
    
    if (*fromAccount >= amount)
    {
        *fromAccount -= amount;
        *toAccount += amount;
        cout << "Перевод доставлен" << endl;
    }
}

void showAllAccounts(double* accounts, int size) {
    if (accounts == nullptr)
    {
        cout << "Счетов не существует" << endl;
        return;
    }

    for (int i = 0; i < size; i++)
    {
        cout <<  "Счет 2 " << i << accounts[i] << endl;
    }
    
}

int findRichestAccount(double* accounts, int size) {
    if (accounts == nullptr)
    {
        cout << "Счетов не существует" << endl;
        return  -1;
    }

    int maxIndex = 0;
    double maxBalance = accounts[0];
    for (int i = 1; i < size; i++)
    {
        if (accounts[i] > maxBalance)
        {
            maxBalance = accounts[i];
            maxIndex = i;
        }
        
    }
    return maxIndex;
    
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    
    double accounts[3] = {1000.0, 500.0, 2500.0};
    
    cout << "=== ВСЕ СЧЕТА ===" << endl;
    showAllAccounts(accounts, 3);
    
    cout << "\n=== ПОИСК БОГАТЕЙШЕГО СЧЕТА ===" << endl;
    int richestIndex = findRichestAccount(accounts, 3);
    cout << "Самый богатый счёт №" << richestIndex << endl;
    cout << "Баланс: "; checkBalance(accounts[richestIndex]);
    
    cout << "\n=== ПЕРЕВОД ОТ БОГАТОГО К БЕДНОМУ ===" << endl;
    transfer(&accounts[richestIndex], &accounts[1], 500.0);
    
    cout << "\n=== ОБНОВЛЁННЫЕ СЧЕТА ===" << endl;
    showAllAccounts(accounts, 3);
    
    return 0;
}