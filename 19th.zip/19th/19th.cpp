#include <iostream>
#include <windows.h>
#include <string>
#include <algorithm>
#include <cctype>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    string password;
    cout << "Введите пароль ";
    cin >> password;

    bool hasLength = password.length() >= 8;
    bool hasDigit = any_of(password.begin(), password.end(), ::isdigit);
    bool hasUpper = any_of(password.begin(), password.end(), ::isupper);
    bool hasLower = any_of(password.begin(), password.end(), ::islower);

    if (!hasLength) {
        cout << "Пароль слишком короткий" << endl;
    }
    if (!hasDigit) {
        cout << "Добавьте хотя бы одну цифру" << endl;
    }
    if (!hasUpper) {
        cout << "Добавьте хотя бы одну заглавную букву" << endl;
    }
    if (!hasLower) {
        cout << "Добавьте хотя бы одну строчную букву" << endl;
    }

    if (hasLength && hasDigit && hasUpper && hasLower) {
        cout << "Пароль надежный" << endl;
    }
    
    return 0;
}