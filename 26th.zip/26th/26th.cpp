#include <iostream>
#include <windows.h>
using namespace std;

void deposit(double& account, double amount) {
    account = account + amount;
    cout << "Пополнение +" << amount << endl;
}

void withdraw(double& account, double amount) {
    if (account >= amount)
    {
        account = account - amount;
        cout << "Списание -" << amount <<endl;
    }
    else
    {
        cout << "Недостаточно средст на счете" << endl;
    }
}

void checkBalance(const double& account) {
    cout << "Ваш баланс " << account << endl; 
}

void transfer(double* fromAccount, double* toAccount, double amount) {

    if (fromAccount == nullptr)
    {
        cout << "Счета не существует" << endl;
    }
    
    if (toAccount == nullptr)
    {
        cout << "Счета не существует" << endl;
    }
    
    if (*fromAccount >= amount)
    {
        *fromAccount -= amount;
        *toAccount += amount;
        cout << "Перевод доставлен" << endl;
    }
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    
    double accountA = 1000.0;
    double accountB = 500.0;
    
    cout << "НАЧАЛЬНЫЕ БАЛАНСЫ" << endl;
    cout << "Счет пользователя А "; checkBalance(accountA);
    cout << "Счет пользователя Б "; checkBalance(accountB);
    
    cout << "\nПЕРЕВОД 300" << endl;
    transfer(&accountA, &accountB, 300.0);
    
    cout << "\nБАЛАНСЫ ПОСЛЕ ПЕРЕВОДА" << endl;
    cout << "Счет пользователя А "; checkBalance(accountA);
    cout << "Счет пользователя Б "; checkBalance(accountB);
    
    return 0;
}