#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int age;
    cout << "Ваш возраст";
    cin >> age;

    if (age >= 18) {
        cout << "Вы совершенолетный" << endl;
    }
    else {
        cout << "Вы несовершенолетний" <<endl;
    }
    return 0;
}