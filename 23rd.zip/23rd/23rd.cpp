#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int a;
    cout << "Введите число" << endl;
    cin >> a;

    int tabl;

    for (int i = 1; i <=10 ;i++)
    {
        tabl = i * a;
        cout << i << " * " << a << " = " << tabl << endl;
    }

    return 0;    
}
