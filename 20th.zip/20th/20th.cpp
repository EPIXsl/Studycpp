#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int currency;
    cout << "Выберите валюту" << endl;
    cout << "1 - USD" << endl;
    cout << "2 - EUR" << endl;
    cout << "3 - JPY" << endl;
    cout << "4 - CNY" << endl;
    cin >> currency;

    double amount;
    cout << "Введите кол-во" << endl;
    cin >> amount;

    const double USD = 83.74;
    const double EUR = 97.53;
    const double JPY = 0.56;
    const double CNY = 11.68;

    if (currency == 1)
    {
        cout << amount * USD <<endl;
    }
    
    else if (currency == 2)
    {
        cout << amount * EUR << endl;
    }
    
    else if (currency == 3)
    {
        cout << amount * JPY << endl;
    }

    else if (currency == 4)
    {
        cout << amount * CNY << endl;
    }
    
    else
    {
        cout << "Неверный выбор валюты" << endl;
    }
    
    return 0;
}