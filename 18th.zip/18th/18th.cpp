#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int day;
    cout << "Введите день недели";
    cin >> day;

    switch(day) {
        case 1:
            cout << "Пн" <<endl;
            break;
        case 2:
            cout << "Вт" <<endl;
            break;
        case 3:
            cout << "Ср" << endl;
            break;
        case 4:
            cout << "Чт" <<endl;
            break;
        case 5:
            cout << "Пт" <<endl;
            break;
        case 6:
            cout << "Сб" << endl;
            break;
        case 7:
            cout << "Вс" << endl;
            break;
        default:
            cout << "Неверный номер дня, введите число от 1 до 7" << endl;    
    }
    return 0;
}