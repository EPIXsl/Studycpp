#include <iostream>
#include <windows.h>
using namespace std;

// ВСЕ ТВОИ ФУНКЦИИ (добавь их сюда)
void deposit(double& account, double amount) {
    account = account + amount;
    cout << "Пополнение +" << amount << endl;
}

void withdraw(double& account, double amount) {
    if (account >= amount)
    {
        account = account - amount;
        cout << "Списание -" << amount <<endl;
    }
    else
    {
        cout << "Недостаточно средст на счете" << endl;
    }
}

void checkBalance(const double& account) {
    cout << "Ваш баланс " << account << endl; 
}

void transfer(double* fromAccount, double* toAccount, double amount) {

    if (fromAccount == nullptr)
    {
        cout << "Счета не существует" << endl;
        return;
    }
    
    if (toAccount == nullptr)
    {
        cout << "Счета не существует" << endl;
        return;
    }
    
    if (*fromAccount >= amount)
    {
        *fromAccount -= amount;
        *toAccount += amount;
        cout << "Перевод доставлен" << endl;
    }

    else
    {
        cout << "Недостаточно средств" << endl;
    }
    
}

void showAllAccounts(double* accounts, int size) {
    if (accounts == nullptr)
    {
        cout << "Счетов не существует" << endl;
        return;
    }

    for (int i = 0; i < size; i++)
    {
        cout << "Счет №" << i << accounts[i] << endl;
    }
    
}

int findRichestAccount(double* accounts, int size) {
    if (accounts == nullptr)
    {
        cout << "Счетов не существует" << endl;
        return  -1;
    }

    int maxIndex = 0;
    double maxBalance = accounts[0];
    for (int i = 1; i < size; i++)
    {
        if (accounts[i] > maxBalance)
        {
            maxBalance = accounts[i];
            maxIndex = i;
        }
        
    }
    return maxIndex;
    
}

void showMenu() {
    cout << "\n=== БАНКОВСКАЯ СИСТЕМА ===" << endl;
    cout << "1. Показать все счета" << endl;
    cout << "2. Пополнить счёт" << endl;
    cout << "3. Снять деньги" << endl;
    cout << "4. Перевести между счетами" << endl;
    cout << "5. Найти самый богатый счёт" << endl;
    cout << "0. Выход" << endl;
    cout << "Выберите операцию: ";
}

int main() {
    SetConsoleOutputCP(CP_UTF8);
    
    double accounts[3] = {1000.0, 500.0, 2500.0};
    const int ACCOUNTS_SIZE = 3;
    
    int choice;

    do {
        showMenu();
        cin >> choice;
        
        switch(choice) {
            case 1: {
                cout << "\n--- ВСЕ СЧЕТА ---" << endl;
                showAllAccounts(accounts, ACCOUNTS_SIZE);
                break;
            }
            case 2: {
                int accountNumber;
                double amount;
                cout << "Введите номер счета (0-" << ACCOUNTS_SIZE-1 << ")" << endl;
                cin >> accountNumber;

                if (accountNumber >= 0 && accountNumber < ACCOUNTS_SIZE)
                {
                    cout << "Введите сумму" << endl;
                    cin >> amount;
                    deposit(accounts[accountNumber], amount);
                }
                else
                {
                    cout << "Неверный номер счета" << endl;
                }
                break;

            }
            case 3: {
                int accountNumber;
                double amount;

                cout << "Введите номер счета (0-" << ACCOUNTS_SIZE-1 << ")" << endl;
                cin >> accountNumber;

                if (accountNumber >=0 && accountNumber < ACCOUNTS_SIZE)
                {
                    cout << "Введите сумму для снятия" << endl;
                    cin >> amount;
                    withdraw(accounts[accountNumber], amount);
                }
                else
                {
                    cout << "Неверный номер счета" << endl;
                }
                break;
            }
            case 4: {
                int fromAccount, toAccount;
                double amount;

                cout << "Введите номер счета с которого будет совершен перевод (0-" << ACCOUNTS_SIZE-1 << ")" << endl;
                cin >> fromAccount;
                cout << "Введите номер счета на который будет совершен перевод (0-" << ACCOUNTS_SIZE-1 << ")" << endl;
                cin >> toAccount;

                if (fromAccount >=0 && fromAccount < ACCOUNTS_SIZE && toAccount >= 0 && toAccount < ACCOUNTS_SIZE)
                {
                    cout << "Введите сумму для перевода" << endl;
                    cin >> amount;
                    transfer(&accounts[fromAccount], &accounts[toAccount], amount);
                }
                else
                {
                    cout << "Неверный номер счета" << endl;
                }
                
                break;
            }
            case 5: {
                cout << "\n--- ПОИСК БОГАТЕЙШЕГО СЧЕТА ---" << endl;
                int richest = findRichestAccount(accounts, ACCOUNTS_SIZE);
                if (richest != -1) {
                    cout << "Самый богатый счёт №" << richest << endl;
                    checkBalance(accounts[richest]);
                }
                break;
            }
            case 0: {
                cout << "Выход из программы" << endl;
                break;
            }
            default: {
                cout << "Неверный выбор" << endl;
            }
        }
        
    } while (choice != 0);
    
    return 0;
}