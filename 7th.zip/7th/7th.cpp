#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int N;
    cout << "Введи число";
    cin >> N;

    for (int i = 1; i <= N; i++)
    {
        cout << i << " "<< endl;
    }
    return 0;
}
    