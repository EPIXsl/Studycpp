#include <iostream>
#include <windows.h>
using namespace std;

int main() {
    SetConsoleOutputCP(CP_UTF8);

    int num;
    cout << "Введите число: ";
    cin >> num;

    bool isEvenPositive = (num > 0) && (num % 2 == 0);

    bool isDivisibleBy3Or5 = (num % 3 == 0) || (num % 5 == 0);

    bool isNotZero = (num != 0);

    bool isInRange = (num >= -10) && (num <= 10);

    bool isOddPositive = (num > 0) && (num % 2 != 0);

    bool isEvenNegative = (num < 0) && (num % 2 == 0);

    bool isOddNegative = (num < 0) && (num % 2 != 0);


    cout << "\nАнализ числа " << num << ":\n";
    cout << "1) " << (isEvenPositive ? "Чётное и положительное" : "Не соответствует") << endl;
    cout << "2) " << (isDivisibleBy3Or5 ? "Кратно 3 или 5" : "Не кратно 3 или 5") << endl;
    cout << "3) " << (isNotZero ? "Не равно нулю" : "Равно нулю") << endl;
    cout << "4) " << (isInRange ? "В диапазоне от -10 до 10" : "Вне диапазона от -10 до 10") << endl;
    cout << "5) " << (isOddPositive ? "Нечётное и положительное" : "Не соответствует") << endl;
    cout << "6) " << (isEvenNegative ? "Чётное и отрицательное" : "Не соответствует") << endl;
    cout << "7) " << (isOddNegative ? "Нечётное и отрицательное" : "Не соответствует") << endl;

    return 0;
}